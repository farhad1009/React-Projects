import React, { Component } from 'react';

class Footer extends Component {
    render() {
        return (
            <div class="footer">
            <div class="copyright">
                <p>Copyright © Designed &amp; Developed by <a href="#" target="_blank">Quixkit</a> 2020</p>
            </div>
        </div>
        );
    }
}

export default Footer;