import React, { Component } from 'react';

function SvgMap() {

    return (
        <>
            
        </>
    )
}

export default SvgMap;