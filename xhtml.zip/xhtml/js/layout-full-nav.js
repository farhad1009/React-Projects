(function($) {
    "use strict"

    new dezSettings({
        sidebarStyle: "full", 
    });


})(jQuery);